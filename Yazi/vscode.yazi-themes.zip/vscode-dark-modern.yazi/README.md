# vscode-dark-modern

[themes/](../) · [vscode-dark-plus](../vscode-dark-plus.yazi/) · [vscode-light-modern](../vscode-light-modern.yazi/) · [vscode-light-plus](../vscode-light-plus.yazi/)

![vscode-dark-modern](./img/1.png)

![vscode-dark-modern](./img/2.png)

![vscode-dark-modern](./img/3.png)

![vscode-dark-modern](./img/4.png)

![vscode-dark-modern](./img/5.png)
