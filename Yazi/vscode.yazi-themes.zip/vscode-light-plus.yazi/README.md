# vscode-light-plus

[themes/](../) · [vscode-dark-modern](../vscode-dark-modern.yazi/) · [vscode-dark-plus](../vscode-dark-plus.yazi/) · [vscode-light-modern](../vscode-light-modern.yazi/)

![vscode-light-plus](./img/1.png)

![vscode-light-plus](./img/2.png)

![vscode-light-plus](./img/3.png)

![vscode-light-plus](./img/4.png)

![vscode-light-plus](./img/5.png)
