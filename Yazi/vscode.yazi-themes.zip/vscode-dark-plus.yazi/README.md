# vscode-dark-plus

[themes/](../) · [vscode-dark-modern](../vscode-dark-modern.yazi/) · [vscode-light-modern](../vscode-light-modern.yazi/) · [vscode-light-plus](../vscode-light-plus.yazi/)

![vscode-dark-plus](./img/1.png)

![vscode-dark-plus](./img/2.png)

![vscode-dark-plus](./img/3.png)

![vscode-dark-plus](./img/4.png)

![vscode-dark-plus](./img/5.png)
