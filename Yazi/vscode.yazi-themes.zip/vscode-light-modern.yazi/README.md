# vscode-light-modern

[themes/](../) · [vscode-dark-modern](../vscode-dark-modern.yazi/) · [vscode-dark-plus](../vscode-dark-plus.yazi/) · [vscode-light-plus](../vscode-light-plus.yazi/)

![vscode-light-modern](./img/1.png)

![vscode-light-modern](./img/2.png)

![vscode-light-modern](./img/3.png)

![vscode-light-modern](./img/4.png)

![vscode-light-modern](./img/5.png)
